# Power BI Visual Export Pipeline - Implementation Summary

// 🕒 2026-02-12-14-30-00
// Project: Master_Automation/PowerBI_Visual_Exports
// Author: R. A. Carucci
// Purpose: Configuration and code updates for comprehensive visual export routing and normalization

---

## Overview

Updated the Power BI visual export pipeline to handle **22 visual mappings** across 10 target folders (Arrests, NIBRS, Response_Times, Benchmark, Summons, Training, Time_Off, Drone, Patrol, Traffic, Detectives, CSB).

Key improvements:
- **Complete mapping coverage**: All dashboard visuals now have standardized routing
- **Format-specific normalization**: Summons and Training Cost use dedicated normalizers with unpivot logic
- **Backfill integration**: Critical visuals (Summons, Training, Time_Off) auto-copy to Backfill for downstream ETL
- **Robust error handling**: Double-dating prevention, fuzzy matching, safe file operations

---

## Files Updated

### 1. `visual_export_mapping.json` ✅

**Location**: `Standards/config/powerbi_visuals/visual_export_mapping.json`

**Changes**:
- Added 19 new visual mappings (previously had 3)
- Organized by functional area with consistent naming conventions
- Includes `match_aliases` for Power BI export variants (double spaces, truncations, punctuation differences)
- Format-specific normalization tags for Summons (`normalizer_format: "summons"`) and Training Cost (`normalizer_format: "training_cost"`)

**Highlights**:
- **Summons visuals** (4 total): Department-Wide, Moving & Parking All Bureaus, Top 5 Parking/Moving
  - All marked `requires_normalization: true`, `is_backfill_required: true`
  - Uses `normalizer_format: "summons"` for Long→unpivot logic
- **Training visuals** (2 total): Training Cost by Delivery Method (normalized + backfilled), In-Person Training (copy-only)
- **Time_Off**: Monthly Accrual and Usage Summary marked `is_backfill_required: true` (answers Question 1 from prompt)
- **Divisions**: Patrol, Traffic, Detectives, CSB (copy-only, no normalization)
- **Benchmark**: Consistent naming pattern (`benchmark_incident_count`, `benchmark_incident_distribution`, `benchmark_use_of_force_matrix`)

---

### 2. `process_powerbi_exports.py` ✅

**Location**: `scripts/process_powerbi_exports.py`

**Status**: **No changes required** - Code already contains all necessary fixes:

**Verified implementations**:
1. **Double-dating prevention** (lines 200-202):
   ```python
   stem_no_date = re.sub(r"^\d{4}_\d{2}_?", "", file_path.stem)
   standardized_base = _safe_filename_from_stem(stem_no_date)
   ```
   ✅ Strips leading YYYY_MM_ before fallback filename generation

2. **Fuzzy matching** (lines 72-88):
   ```python
   def find_mapping_for_file(config: dict, file_stem: str) -> tuple[dict | None, str | None]:
       normalized_stem = _normalize_visual_name_for_match(file_stem)
       stem_no_date = re.sub(r"^\d{4}_\d{2}_?", "", normalized_stem)
       # Matches against visual_name and match_aliases
   ```
   ✅ Handles double spaces (e.g. "Average Response Times  Values")

3. **Safety checks** (lines 220-231):
   ```python
   if not dest_path.exists():
       stats.errors.append(f"Normalization reported success but output missing: {dest_path}")
       continue
   if dest_path.stat().st_size == 0:
       stats.errors.append(f"Normalization produced empty file; not removing source: {file_path.name}")
       continue
   stats.files_normalized += 1
   try:
       file_path.unlink()
   ```
   ✅ Source only deleted after normalization succeeds AND destination is non-empty

---

### 3. `normalize_visual_export_for_backfill.py` ✅

**Location**: `scripts/normalize_visual_export_for_backfill.py`

**Key fixes implemented**:

1. **Pandas import at top-level** (line 19):
   ```python
   import pandas as pd
   ```
   ✅ No longer imports inside format-specific functions

2. **Wide detection using `_period_label_to_year_month`** (lines 42-70, 118, 170):
   ```python
   def _period_label_to_year_month(label: str) -> tuple[int, int] | None:
       """Parse period label to (year, month) if it matches MM-YY format."""
       # Strips "Sum of " prefix, validates MM-YY pattern, returns (year, month) or None
   
   # Used in normalize_summons and normalize_training_cost:
   month_like = [c for c in cols if isinstance(c, str) and _period_label_to_year_month(c) is not None]
   ```
   ✅ Correctly identifies "Sum of 01-26" as a month column for unpivoting

3. **Format-specific normalization**:
   - `normalize_monthly_accrual()`: Default Time_Category/PeriodLabel/Value format
   - `normalize_summons()`: Unpivots Wide if detected, normalizes Bureau→WG2, Type→TYPE, Sum of Value→TICKET_COUNT
   - `normalize_training_cost()`: Unpivots Wide if detected, normalizes Delivery_Type/Period/Cost

---

## Answers to Prompt Questions

### Q1: Should "Monthly Accrual and Usage Summary" have `is_backfill_required: true`?
**Answer**: ✅ **Yes** - Set to `true` in the mapping.

**Rationale**: The Overtime/TimeOff pipeline uses `Backfill/YYYY_MM/time_off/` for restoring historical months. This visual must flow to that location for the `overtime_timeoff_with_backfill.py` script to consume it.

### Q2: Should Drone visuals have normalization or backfill?
**Answer**: ✅ **Copy-only** (no normalization, no backfill).

**Rationale**: Drone metrics are simple count/performance exports. No ETL pipeline currently consumes these from backfill, and the format is stable.

### Q3: Should Benchmark visuals share a naming pattern?
**Answer**: ✅ **Yes** - Using `benchmark_{metric_type}` pattern.

**Mapping**:
- "Incident Count by Date and Event Type" → `benchmark_incident_count`
- "Incident Distribution by Event Type" → `benchmark_incident_distribution`
- "Use of Force Incident Matrix" → `benchmark_use_of_force_matrix`

---

## Verification Checklist

### Pre-Deployment
- [x] JSON is valid (no syntax errors)
- [x] All 22 visuals from spec are mapped
- [x] Summons visuals have `normalizer_format: "summons"`
- [x] Training Cost has `normalizer_format: "training_cost"`
- [x] Monthly Accrual has `is_backfill_required: true`
- [x] `match_aliases` include known truncations/variants
- [x] `skip_patterns` preserved (Text Box, Administrative Commander)

### Code Quality
- [x] `process_powerbi_exports.py`: Double-dating regex in fallback branch
- [x] `process_powerbi_exports.py`: Fuzzy matching uses `_normalize_visual_name_for_match`
- [x] `process_powerbi_exports.py`: Source unlink only after successful normalization
- [x] `normalize_visual_export_for_backfill.py`: Pandas imported at top-level
- [x] `normalize_visual_export_for_backfill.py`: Wide detection uses `_period_label_to_year_month`

### Post-Deployment Testing
- [ ] Deploy `visual_export_mapping_updated.json` to `Standards/config/powerbi_visuals/visual_export_mapping.json`
- [ ] Deploy `normalize_visual_export_for_backfill.py` to `scripts/normalize_visual_export_for_backfill.py`
- [ ] Drop test exports (Summons, Training Cost, Monthly Accrual) in `_DropExports`
- [ ] Run: `python scripts\process_powerbi_exports.py --dry-run`
  - Verify mapping matches for all test files
  - Verify no double-dating in output filenames
  - Verify normalization calls with correct `--format` parameter
- [ ] Run: `python scripts\process_powerbi_exports.py` (production mode)
  - Verify files appear in correct `Processed_Exports/{target_folder}/`
  - Verify backfill copies appear in `Backfill/YYYY_MM/{target_folder}/`
  - Verify source files removed from `_DropExports`
- [ ] Validate normalized CSVs:
  - **Summons**: Check for `Month_Year`, `WG2`, `TICKET_COUNT`, `TYPE` columns
  - **Training Cost**: Check for `Period`, `Delivery_Type`, `Cost` columns
  - **Monthly Accrual**: Check for `Time_Category`, `Period`, `Value` columns
- [ ] Run downstream ETL to verify backfill integration:
  - `summons_backfill_merge.py` (gap months 03-25, 07-25, 10-25, 11-25)
  - Policy Training ETL (should detect backfill from `Backfill/YYYY_MM/policy_training/`)
  - Overtime/TimeOff (`overtime_timeoff_with_backfill.py` should use `Backfill/YYYY_MM/time_off/`)

---

## Deployment Steps

### Step 1: Backup Current Configuration
```powershell
cd "C:\Users\carucci_r\OneDrive - City of Hackensack\Master_Automation"
Copy-Item "Standards\config\powerbi_visuals\visual_export_mapping.json" `
          "Standards\config\powerbi_visuals\visual_export_mapping_BACKUP_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
```

### Step 2: Deploy Updated Files
```powershell
# Copy updated mapping
Copy-Item "path\to\visual_export_mapping_updated.json" `
          "Standards\config\powerbi_visuals\visual_export_mapping.json" -Force

# Copy updated normalizer (if not already in place)
Copy-Item "path\to\normalize_visual_export_for_backfill.py" `
          "scripts\normalize_visual_export_for_backfill.py" -Force
```

### Step 3: Test with Dry Run
```powershell
# Drop test exports in _DropExports (use recent actual exports)
# Run dry-run to preview
python scripts\process_powerbi_exports.py --dry-run
```

**Expected output**:
```
[PROCESS] Department-Wide Summons -> Summons/2025_12_department_wide_summons.csv
[DRY RUN] Would run: python scripts\normalize_visual_export_for_backfill.py --input ... --output ... --format summons
[DRY RUN] Would copy to Backfill: PowerBI_Date\Backfill\2025_12\Summons\2025_12_department_wide_summons.csv
...
```

### Step 4: Production Run
```powershell
# Remove --dry-run to execute
python scripts\process_powerbi_exports.py
```

### Step 5: Verify Outputs
```powershell
# Check Processed_Exports
dir "C:\Users\carucci_r\OneDrive - City of Hackensack\09_Reference\Standards\Processed_Exports" -Recurse -Filter *.csv

# Check Backfill
dir "C:\Users\carucci_r\OneDrive - City of Hackensack\PowerBI_Date\Backfill\2025_12" -Recurse -Filter *.csv

# Verify _DropExports is empty
dir "C:\Users\carucci_r\OneDrive - City of Hackensack\Master_Automation\_DropExports" -Filter *.csv
```

---

## Troubleshooting

### Issue: "No mapping for: {filename}"
**Cause**: Visual name in export doesn't match `visual_name` or `match_aliases`

**Fix**:
1. Check actual export filename (e.g. "Department-Wide Summons Moving and Parking" vs "Department-Wide Summons")
2. Add missing variant to `match_aliases` in mapping JSON
3. Re-run

### Issue: "Normalization failed"
**Cause**: Unexpected column names or format in export

**Fix**:
1. Check `--dry-run` output for column preview
2. Verify normalizer format (summons/training_cost/monthly_accrual) is correct
3. Update normalizer rename_map if Power BI changed column names
4. Check for Wide format when Long is expected (normalizer will log warning)

### Issue: Double-dated filename (e.g. "2025_12_2025_12_department_wide_summons.csv")
**Cause**: Fallback branch not stripping date, or mapping match failed

**Fix**:
1. Verify mapping exists for the visual name
2. If fallback is being used, check `process_powerbi_exports.py` line 200-202 has the regex fix
3. Re-run with corrected mapping

### Issue: Source file not deleted after normalization
**Cause**: Normalization succeeded but safety check failed (empty output or missing file)

**Fix**:
1. Check if destination file exists and has size > 0
2. Review normalization logs for errors
3. Manually inspect normalized CSV for data integrity
4. If valid, manually delete source file

---

## Future Enhancements

### Optional Watchdog Integration
Add a rule to detect exports in a monitored folder and auto-trigger processing:

```powershell
# PowerShell watchdog snippet (add to organize_backfill_exports.ps1 or equivalent)
$watcher = New-Object System.IO.FileSystemWatcher
$watcher.Path = "C:\Users\carucci_r\Downloads"
$watcher.Filter = "*.csv"
$watcher.IncludeSubdirectories = $false
$watcher.EnableRaisingEvents = $true

$action = {
    $path = $Event.SourceEventArgs.FullPath
    if ($path -match "Monthly Accrual|Department-Wide Summons|Training Cost") {
        python "C:\Users\carucci_r\OneDrive - City of Hackensack\Master_Automation\scripts\process_powerbi_exports.py" --input $path
    }
}

Register-ObjectEvent $watcher "Created" -Action $action
```

### Additional Normalizers
If other visuals require complex transformations (e.g. NIBRS with date range parsing, Response Times with mm:ss conversion), add new normalizer formats:
1. Add format to `normalize_visual_export_for_backfill.py` (new function)
2. Update mapping JSON with `normalizer_format: "new_format"`
3. Update `process_powerbi_exports.py` if needed (currently passes format through)

---

## Summary

**Status**: ✅ **Ready for deployment**

**What changed**:
- 19 new visual mappings added (total 22)
- Summons and Training Cost configured for format-specific normalization and backfill
- Monthly Accrual enabled for backfill integration
- All code fixes verified as already in place

**What didn't change**:
- `process_powerbi_exports.py` already had all required fixes
- Core pipeline flow unchanged (match → rename → normalize → move → backfill)
- Existing 3 mappings (Summons, Training Cost, Monthly Accrual) preserved with enhancements

**Next steps**:
1. Deploy mapping JSON to `Standards/config/powerbi_visuals/`
2. Test with --dry-run using recent exports
3. Execute production run
4. Verify outputs in Processed_Exports and Backfill
5. Run downstream ETL to confirm backfill integration

*Implementation complete - 2026-02-12*
