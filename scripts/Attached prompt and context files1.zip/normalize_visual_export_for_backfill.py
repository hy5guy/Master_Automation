#!/usr/bin/env python3
"""
Normalize Power BI visual exports for backfill consumption.

Handles Long (default) and Wide formats, normalizes column names and period labels
(e.g. "Sum of 11-25" -> "11-25"), and writes to Backfill/YYYY_MM/{target_folder}/.

Usage:
  python normalize_visual_export_for_backfill.py --input <path> --output <path> [--format summons|training_cost] [--dry-run]
"""

from __future__ import annotations

import argparse
import logging
import re
import sys
from pathlib import Path
from typing import TYPE_CHECKING

import pandas as pd

try:
    from path_config import get_onedrive_root
except ImportError:
    import os
    def get_onedrive_root() -> Path:
        base = os.environ.get("ONEDRIVE_BASE") or os.environ.get("ONEDRIVE_HACKENSACK")
        if base:
            return Path(base)
        return Path(r"C:\Users\carucci_r\OneDrive - City of Hackensack")


logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


def _period_label_to_year_month(label: str) -> tuple[int, int] | None:
    """
    Parse period label to (year, month) if it matches MM-YY format.
    Returns None if not a valid month label.
    
    Examples:
      "01-25" -> (2025, 1)
      "Sum of 11-25" -> (2025, 11)
      "Random Text" -> None
    """
    if not isinstance(label, str):
        return None
    
    # Strip "Sum of " prefix if present
    clean = label.strip()
    if clean.lower().startswith("sum of "):
        clean = clean[7:].strip()
    
    # Match MM-YY pattern
    m = re.match(r"^(\d{2})-(\d{2})$", clean)
    if not m:
        return None
    
    mm, yy = m.groups()
    month = int(mm)
    year = int(yy)
    
    if not (1 <= month <= 12):
        return None
    
    # Convert 2-digit year to 4-digit (assume 20xx)
    if year < 100:
        year = 2000 + year
    
    return (year, month)


def normalize_monthly_accrual(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalize Monthly Accrual and Usage Summary (default format).
    Handles Long format with Time Category, PeriodLabel, Sum of Value.
    """
    logger.info("Normalizing Monthly Accrual format (default)")
    
    # Normalize column names
    rename_map = {
        "Time Category": "Time_Category",
        "Sum of Value": "Value",
        "Sum of  Value": "Value",  # double space variant
        "PeriodLabel": "Period",
    }
    
    df = df.rename(columns=rename_map)
    
    # Ensure required columns exist
    if "Period" in df.columns:
        # Clean period labels (e.g. "Sum of 11-25" -> "11-25")
        df["Period"] = df["Period"].astype(str).str.strip()
        df["Period"] = df["Period"].str.replace(r"^Sum of ", "", regex=True).str.strip()
    
    if "Value" in df.columns:
        df["Value"] = pd.to_numeric(df["Value"], errors="coerce").fillna(0)
    
    return df


def normalize_summons(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalize Summons visual exports (Long format).
    Expected columns: PeriodLabel or Month_Year, Bureau or WG2, Moving/Parking or TYPE, Sum of Value or TICKET_COUNT.
    """
    logger.info("Normalizing Summons format")
    
    # Detect format: Long vs Wide
    cols = df.columns.tolist()
    month_like = [c for c in cols if isinstance(c, str) and _period_label_to_year_month(c) is not None]
    
    if month_like:
        logger.warning(
            "Summons export appears to be Wide format (month columns: %s). "
            "Long format (PeriodLabel) is required for backfill. Attempting to unpivot.",
            month_like[:5]
        )
        # Attempt to unpivot
        id_cols = [c for c in cols if c not in month_like]
        df = df.melt(id_vars=id_cols, value_vars=month_like, var_name="PeriodLabel", value_name="TICKET_COUNT")
    
    # Normalize column names
    rename_map = {
        "PeriodLabel": "Month_Year",
        "Bureau": "WG2",
        "Sum of Value": "TICKET_COUNT",
        "Value": "TICKET_COUNT",
        "Sum of TICKET_COUNT": "TICKET_COUNT",
        "Moving/Parking": "TYPE",
        "Type": "TYPE",
    }
    
    df = df.rename(columns=rename_map)
    
    # Clean period labels
    if "Month_Year" in df.columns:
        df["Month_Year"] = df["Month_Year"].astype(str).str.strip()
        df["Month_Year"] = df["Month_Year"].str.replace(r"^Sum of ", "", regex=True).str.strip()
    
    # Ensure TICKET_COUNT is numeric
    if "TICKET_COUNT" in df.columns:
        df["TICKET_COUNT"] = pd.to_numeric(df["TICKET_COUNT"], errors="coerce").fillna(0)
    
    # Ensure WG2 and TYPE exist
    if "WG2" not in df.columns:
        df["WG2"] = "Unknown"
    if "TYPE" not in df.columns:
        df["TYPE"] = "Unknown"
    
    df["WG2"] = df["WG2"].fillna("Unknown").astype(str)
    df["TYPE"] = df["TYPE"].fillna("Unknown").astype(str)
    
    return df


def normalize_training_cost(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalize Training Cost by Delivery Method (Long format).
    Expected columns: Delivery_Type, PeriodLabel or period columns, Sum of Value or Cost.
    """
    logger.info("Normalizing Training Cost format")
    
    # Detect format: Long vs Wide
    cols = df.columns.tolist()
    month_like = [c for c in cols if isinstance(c, str) and _period_label_to_year_month(c) is not None]
    
    if month_like:
        logger.info("Training Cost export is Wide format (month columns: %s). Unpivoting to Long.", month_like[:5])
        # Unpivot
        id_cols = [c for c in cols if c not in month_like]
        df = df.melt(id_vars=id_cols, value_vars=month_like, var_name="PeriodLabel", value_name="Cost")
    
    # Normalize column names
    rename_map = {
        "PeriodLabel": "Period",
        "Delivery_Type": "Delivery_Type",
        "Sum of Value": "Cost",
        "Value": "Cost",
        "Sum of Cost": "Cost",
    }
    
    df = df.rename(columns=rename_map)
    
    # Clean period labels
    if "Period" in df.columns:
        df["Period"] = df["Period"].astype(str).str.strip()
        df["Period"] = df["Period"].str.replace(r"^Sum of ", "", regex=True).str.strip()
    
    # Ensure Cost is numeric
    if "Cost" in df.columns:
        df["Cost"] = pd.to_numeric(df["Cost"], errors="coerce").fillna(0)
    
    # Ensure Delivery_Type exists
    if "Delivery_Type" not in df.columns:
        df["Delivery_Type"] = "Unknown"
    
    return df


def normalize_export(
    input_path: Path,
    output_path: Path,
    normalizer_format: str = "monthly_accrual",
    dry_run: bool = False,
) -> bool:
    """
    Normalize a Power BI visual export and write to output_path.
    
    Args:
        input_path: Source CSV file
        output_path: Destination CSV file
        normalizer_format: Format type (monthly_accrual, summons, training_cost)
        dry_run: If True, preview only (no file write)
    
    Returns:
        True on success, False on failure
    """
    if not input_path.exists():
        logger.error("Input file not found: %s", input_path)
        return False
    
    try:
        # Read CSV
        df = pd.read_csv(input_path, low_memory=False)
        
        if df.empty:
            logger.warning("Input file is empty: %s", input_path)
            return False
        
        logger.info("Loaded %d rows from %s", len(df), input_path.name)
        
        # Apply normalization based on format
        if normalizer_format == "summons":
            df = normalize_summons(df)
        elif normalizer_format == "training_cost":
            df = normalize_training_cost(df)
        else:  # monthly_accrual (default)
            df = normalize_monthly_accrual(df)
        
        if dry_run:
            logger.info("[DRY RUN] Would write %d rows to %s", len(df), output_path)
            logger.info("[DRY RUN] Preview (first 5 rows):\n%s", df.head())
            return True
        
        # Write output
        output_path.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(output_path, index=False, encoding="utf-8")
        logger.info("Wrote %d rows to %s", len(df), output_path)
        return True
        
    except Exception as e:
        logger.error("Normalization failed: %s", e, exc_info=True)
        return False


def main() -> int:
    parser = argparse.ArgumentParser(description="Normalize Power BI visual exports for backfill")
    parser.add_argument("--input", type=Path, required=True, help="Input CSV file")
    parser.add_argument("--output", type=Path, required=True, help="Output CSV file")
    parser.add_argument(
        "--format",
        choices=["monthly_accrual", "summons", "training_cost"],
        default="monthly_accrual",
        help="Normalization format (default: monthly_accrual)"
    )
    parser.add_argument("--dry-run", action="store_true", help="Preview only, do not write output")
    
    args = parser.parse_args()
    
    success = normalize_export(
        input_path=args.input,
        output_path=args.output,
        normalizer_format=args.format,
        dry_run=args.dry_run,
    )
    
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
