# 13-Month Rolling Window Enforcement - Implementation Guide

// 🕒 2026-02-12-15-00-00
// Project: Master_Automation/PowerBI_Visual_Exports
// Author: R. A. Carucci
// Purpose: Add 13-month rolling data window validation to visual export pipeline

---

## Overview

Ensures all Power BI visual exports maintain a **consistent 13-month rolling window** ending with the previous complete month, preventing incomplete current-month data from affecting dashboards.

### Operational Rule

**Current Date**: February 12, 2026

| Component | Value | Calculation |
|-----------|-------|-------------|
| **End Date** | January 2026 (01-26) | Previous month from today |
| **Start Date** | January 2025 (01-25) | 12 months before end date |
| **Window** | 13 months | Start month + 12 months |
| **Periods** | 01-25, 02-25, ..., 12-25, 01-26 | Continuous rolling window |

**Key Principle**: Never include the current month (it may be incomplete).

---

## What Changed

### 1. Enhanced Normalizer Script ✅

**File**: `normalize_visual_export_for_backfill.py`

**New Functions**:
```python
def calculate_13_month_window(as_of_date: datetime | None = None) -> tuple[str, str, list[str]]:
    """
    Calculate 13-month rolling window ending with previous complete month.
    
    Returns:
        (start_period, end_period, all_periods)
        Periods in MM-YY format
    
    Example (today = 2026-02-12):
        ('01-25', '01-26', ['01-25', '02-25', ..., '01-26'])
    """

def enforce_13_month_window(df: pd.DataFrame, period_column: str = "Period") -> pd.DataFrame:
    """
    Filter dataframe to only include records from the 13-month rolling window.
    
    Behavior:
    - Normalizes period labels (strips "Sum of " prefix)
    - Filters to valid periods only
    - Logs removed periods and missing periods
    - Validates data coverage
    """
```

**Updated Normalizers**:
- `normalize_monthly_accrual()` - Added `enforce_window` parameter
- `normalize_summons()` - Added `enforce_window` parameter
- `normalize_training_cost()` - Added `enforce_window` parameter

**New CLI Parameter**:
```bash
python normalize_visual_export_for_backfill.py \
  --input export.csv \
  --output normalized.csv \
  --enforce-13-month  # ← NEW FLAG
```

---

### 2. Updated Mapping Configuration ✅

**File**: `visual_export_mapping.json`

**New Field**: `enforce_13_month_window` (boolean)

**Example**:
```json
{
  "visual_name": "Department-Wide Summons",
  "standardized_filename": "department_wide_summons",
  "requires_normalization": true,
  "normalizer_format": "summons",
  "is_backfill_required": true,
  "enforce_13_month_window": true,  // ← NEW FIELD
  "target_folder": "Summons"
}
```

**Visuals with 13-Month Enforcement** (24 total):

| Category | Visuals | Count |
|----------|---------|-------|
| **Summons** | Department-Wide, All Bureaus, Top 5 Parking, Top 5 Moving | 4 |
| **Training** | Cost by Delivery Method, In-Person Training | 2 |
| **Time Off** | Monthly Accrual and Usage Summary | 1 |
| **NIBRS** | 13-Month Clearance Rate Trend | 1 |
| **Response Times** | Average Response Times, By Priority | 2 |
| **Benchmark** | Incident Count, Use of Force Matrix | 2 |
| **Drone** | DFR Activity, Non-DFR Performance | 2 |
| **Divisions** | Patrol, Traffic, Detectives (Parts 1 & 2, Clearance, Dispositions), CSB | 7 |
| **Support** | Motor Vehicle Accidents, STACP (Parts 1 & 2), Records & Evidence, SSOCC | 5 |
| **Other** | Social Media Posts, Chief Executive Duties | 2 |

**New Target Folders Added**:
- `STACP` - School Threat Assessment & Crime Prevention
- `Community_Engagement` - Social Media Posts
- `Executive` - Chief Executive Duties
- `Support_Services` - Records & Evidence Unit
- `SSOCC` - Safe Streets Operations Control Center

---

### 3. Process Script Updates 🔧

**File**: `process_powerbi_exports.py`

**Changes Required** (see `process_powerbi_exports_PATCH.txt`):

1. **Update `run_normalize()` signature**:
   ```python
   # Add enforce_13_month parameter
   def run_normalize(
       input_path: Path, 
       output_path: Path, 
       dry_run: bool, 
       normalizer_format: str | None = None,
       enforce_13_month: bool = False  # ← NEW
   ) -> bool:
       # ... existing code ...
       if enforce_13_month:
           cmd.append("--enforce-13-month")
   ```

2. **Update dry-run preview** (around line 207):
   ```python
   enforce_window = mapping.get("enforce_13_month_window", False)
   # ... build command ...
   if enforce_window:
       _dry_cmd.append("--enforce-13-month")
   ```

3. **Update production run** (around line 217):
   ```python
   enforce_window = mapping.get("enforce_13_month_window", False)
   ok = run_normalize(
       file_path, 
       dest_path, 
       dry_run=False, 
       normalizer_format=fmt,
       enforce_13_month=enforce_window
   )
   ```

---

## How It Works

### Data Flow

```
Power BI Export
    ↓
process_powerbi_exports.py
    ├── Read mapping JSON
    ├── Check enforce_13_month_window flag
    └── Call normalizer with --enforce-13-month
         ↓
normalize_visual_export_for_backfill.py
    ├── Calculate window: 01-25 to 01-26 (13 months)
    ├── Normalize period labels
    ├── Filter df[Period].isin(['01-25', '02-25', ..., '01-26'])
    ├── Log removed periods (outside window)
    ├── Validate coverage (missing periods warning)
    └── Write filtered CSV
         ↓
Processed_Exports/{target_folder}/
         ↓
Backfill/{YYYY_MM}/{target_folder}/ (if backfill_required)
```

### Example Logs

**With Enforcement** (today = 2026-02-12):
```
INFO: Enforcing 13-month window: 01-25 through 01-26 (13 periods)
INFO: Filtered out 45 rows from 2 periods outside 13-month window: ['11-24', '12-24']
WARNING: 13-month window incomplete: 1 missing periods: ['03-25']
INFO: 13-month window validated: 12 periods present, 1,234 rows
```

**Without Enforcement**:
```
INFO: Normalizing Summons format
INFO: Wrote 1,279 rows to 2025_12_department_wide_summons.csv
```

---

## Deployment Steps

### Step 1: Backup Current Files
```powershell
cd "C:\Users\carucci_r\OneDrive - City of Hackensack\Master_Automation"

# Backup mapping
Copy-Item "Standards\config\powerbi_visuals\visual_export_mapping.json" `
          "Standards\config\powerbi_visuals\visual_export_mapping_BACKUP_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"

# Backup normalizer
Copy-Item "scripts\normalize_visual_export_for_backfill.py" `
          "scripts\normalize_visual_export_for_backfill_BACKUP_$(Get-Date -Format 'yyyyMMdd_HHmmss').py"
```

### Step 2: Deploy Updated Files
```powershell
# Copy new mapping (32 visuals, enforce_13_month_window flags)
Copy-Item "path\to\visual_export_mapping_with_13month.json" `
          "Standards\config\powerbi_visuals\visual_export_mapping.json" -Force

# Copy enhanced normalizer (13-month window logic)
Copy-Item "path\to\normalize_visual_export_for_backfill_v2.py" `
          "scripts\normalize_visual_export_for_backfill.py" -Force
```

### Step 3: Apply Patch to process_powerbi_exports.py
```powershell
# Manually edit process_powerbi_exports.py using process_powerbi_exports_PATCH.txt
# OR use the complete updated version if provided
```

### Step 4: Test with Sample Export
```powershell
# Test standalone normalizer
python scripts\normalize_visual_export_for_backfill.py `
  --input "test_export.csv" `
  --output "test_normalized.csv" `
  --enforce-13-month `
  --dry-run

# Expected output:
# INFO: 13-month window: 01-25 to 01-26 (13 periods)
# INFO: Loaded 100 rows from test_export.csv
# INFO: Enforcing 13-month window: 01-25 through 01-26 (13 periods)
# INFO: Filtered out X rows from Y periods outside 13-month window: [...]
# [DRY RUN] Periods in output: ['01-25', '02-25', ..., '01-26']
```

### Step 5: Test Full Pipeline
```powershell
# Drop a recent export in _DropExports
Copy-Item "path\to\recent_export.csv" "_DropExports\"

# Run dry-run
python scripts\process_powerbi_exports.py --dry-run

# Verify output shows --enforce-13-month flag for applicable visuals
# [DRY RUN] Would run: python ... --enforce-13-month

# Production run
python scripts\process_powerbi_exports.py
```

---

## Validation & Troubleshooting

### Validate 13-Month Window

**Manual Check**:
```powershell
# Import CSV and check unique periods
python -c "
import pandas as pd
df = pd.read_csv('Processed_Exports/Summons/2025_12_department_wide_summons.csv')
periods = sorted(df['Month_Year'].unique()) if 'Month_Year' in df.columns else []
print(f'Periods: {periods}')
print(f'Count: {len(periods)} (expected: 13)')
"
```

**Expected Output** (today = 2026-02-12):
```
Periods: ['01-25', '02-25', '03-25', '04-25', '05-25', '06-25', '07-25', '08-25', '09-25', '10-25', '11-25', '12-25', '01-26']
Count: 13 (expected: 13)
```

### Common Issues

#### Issue: "13-month window incomplete: X missing periods"
**Cause**: Source data missing certain months (gap months, no activity)

**Fix**: 
- **Expected behavior** for low-activity periods (e.g., no summons in July)
- If unexpected, check source export date range in Power BI
- Verify backfill contains missing months

#### Issue: "Cannot enforce 13-month window: column 'Period' not found"
**Cause**: Normalizer didn't rename column correctly, or export format changed

**Fix**:
1. Check actual column names: `print(df.columns.tolist())`
2. Update normalizer rename_map if Power BI changed headers
3. Ensure period_column parameter matches actual column name

#### Issue: "Filtered out 200+ rows from 6 periods"
**Cause**: Export includes data outside 13-month window (older history or current month)

**Fix**:
- **Expected behavior** - enforcement is working correctly
- Verify removed periods are indeed outside window
- Check if Power BI visual needs date filter adjustment

#### Issue: Window calculation wrong (e.g., includes current month)
**Cause**: Logic error in calculate_13_month_window()

**Fix**:
1. Test window calculation standalone:
   ```python
   from normalize_visual_export_for_backfill import calculate_13_month_window
   start, end, periods = calculate_13_month_window()
   print(f"Today: {datetime.now().strftime('%Y-%m-%d')}")
   print(f"Window: {start} to {end}")
   print(f"Periods: {periods}")
   ```
2. Verify end date is previous month
3. Verify 13 total periods

---

## Verification Checklist

### Pre-Deployment
- [x] 32 visual mappings defined
- [x] 24 visuals have `enforce_13_month_window: true`
- [x] New target folders added (STACP, Community_Engagement, Executive, Support_Services, SSOCC)
- [x] Normalizer has `calculate_13_month_window()` and `enforce_13_month_window()` functions
- [x] CLI parameter `--enforce-13-month` added
- [x] Process script patch documented

### Post-Deployment
- [ ] Mapping JSON deployed to Standards/config/powerbi_visuals/
- [ ] Normalizer script deployed to scripts/
- [ ] Process script patched (3 changes applied)
- [ ] Standalone test: `--enforce-13-month --dry-run` works
- [ ] Pipeline test: exports processed with correct window
- [ ] Validation: CSV periods match expected 13-month window
- [ ] Log review: removed periods logged, missing periods flagged

### Data Quality Checks
- [ ] Summons exports: 13 months only (01-25 to 01-26)
- [ ] Training Cost: 13 months, no current month
- [ ] Monthly Accrual: 13 months, backfill integration works
- [ ] Division exports (Patrol, Traffic, Detectives, CSB): 13 months
- [ ] No exports include February 2026 (current month)

---

## Benefits

### Before
- Exports could include incomplete current month data
- Inconsistent reporting windows month-to-month
- Manual verification required
- Dashboards showed partial data for current month

### After
- ✅ **Consistent 13-month window** across all exports
- ✅ **Automated enforcement** - no manual checks needed
- ✅ **Clear validation** - logs show missing/removed periods
- ✅ **Data integrity** - prevents incomplete month issues
- ✅ **Predictable reporting** - same window logic every month

---

## Monthly Execution Notes

**As each month rolls forward**:
- Window automatically adjusts (e.g., on March 1, 2026: window becomes 02-25 to 02-26)
- No configuration changes needed
- Previous exports remain valid (they captured their respective 13-month windows)
- Backfill folders accumulate monthly snapshots

**Example Timeline**:
| Run Date | Window Start | Window End | Periods |
|----------|-------------|-----------|---------|
| Feb 12, 2026 | 01-25 | 01-26 | 01-25 ... 01-26 (13) |
| Mar 5, 2026 | 02-25 | 02-26 | 02-25 ... 02-26 (13) |
| Apr 15, 2026 | 03-25 | 03-26 | 03-25 ... 03-26 (13) |

---

## Future Enhancements

### Optional: Configurable Window Size
If different visuals need different windows (e.g., 6-month, 12-month, 24-month):

```json
{
  "visual_name": "Quarterly Summary",
  "enforce_rolling_window": true,
  "rolling_window_months": 6,  // ← NEW: configurable size
  "target_folder": "Quarterly"
}
```

### Optional: Custom End Date
For historical analysis or fixed reporting periods:

```bash
python normalize_visual_export_for_backfill.py \
  --input export.csv \
  --output normalized.csv \
  --enforce-13-month \
  --as-of-date 2025-12-31  # ← Use Dec 2025 as "today"
```

---

## Summary

**Status**: ✅ **Ready for deployment**

**Key Changes**:
- 13-month rolling window calculation logic
- Automatic period filtering in normalizer
- 24 visuals configured for enforcement
- Validation logging (removed/missing periods)
- 8 new target folders for comprehensive coverage

**Impact**:
- Ensures consistent, comparable reporting intervals
- Prevents incomplete current-month data issues
- Automated enforcement eliminates manual checks
- Clear audit trail through validation logs

**Next Steps**:
1. Deploy mapping JSON and normalizer script
2. Apply patch to process_powerbi_exports.py
3. Test with sample exports (dry-run → production)
4. Validate 13-month window in output CSVs
5. Monitor logs for missing/removed period warnings

*Implementation Guide - 2026-02-12*
